export default class Player {
  readonly symbol;

  constructor(symbol: string) {
    this.symbol = symbol;
  }
}